# lungs_segmentation
Automated lung segmentation in chest-x ray 
